 
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

import os
from collections import deque

from PySide6.QtCore import Qt, Slot, QTimer, QPoint
from PySide6.QtGui import QPainter, QFont, QScreen, QPixmap, QImage, QColor
from PySide6.QtWidgets import QWidget, QFrame, QVBoxLayout, QPushButton, QLabel
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QApplication
from PySide6.QtDesigner import QPyDesignerCustomWidgetCollection

import st_dtdl_gui
from st_dtdl_gui.Widgets.PlotWidget import PlotLabel

class ClassifierOutputWidget(QWidget):    
    def __init__(self, controller, comp_name, comp_display_name, out_classes, p_id = 0, parent=None):
        """AI is creating summary for __init__
        Args:
            controller ([type]): [description]
            comp_name ([type]): [description]
            comp_display_name ([type]): [description]
            out_classes (dict): a dict (class name, image_path)
            p_id (int, optional): [description]. Defaults to 0.
            parent ([type], optional): [description]. Defaults to None.
        """        
        super().__init__(parent)
        self.parent = parent
        self.controller = controller
        self.controller.sig_logging.connect(self.s_is_logging)

        self._data = dict() # dict of queues
        self._data[0] = deque(maxlen=200000)
        
        self.is_docked = True
        self.app_qt = self.controller.qt_app

        self.p_id = p_id
        self.comp_name = comp_name
        self.comp_display_name = comp_display_name
        
        self.timer_interval = 0.2

        self.out_classes = out_classes
        self.output_class_widget = {}
        self.output_class_pixmaps = {}
        
        QPyDesignerCustomWidgetCollection.registerCustomWidget(ClassifierOutputWidget, module="ClassifierOutputWidget")
        loader = QUiLoader()
        # class_out_widget = loader.load("ST_DTDL_GUI\\UI\\classifier_output_widget.ui", parent)
        class_out_widget = loader.load(os.path.join(os.path.dirname(st_dtdl_gui.__file__),"UI","classifier_output_widget.ui"), parent)
        frame_title = class_out_widget.findChild(QFrame,"frame_title")
        frame_contents = class_out_widget.findChild(QFrame,"frame_contents")
        #TODO check the following
        frame_output_classes = class_out_widget.findChild(QFrame,"frame_output_classes")
        pushButton_pop_out = frame_title.findChild(QPushButton, "pushButton_pop_out")
        pushButton_pop_out.clicked.connect(self.clicked_pop_out_button)

        for output_class in self.out_classes:
            # self.output_class_widget[output_class] = loader.load("ST_DTDL_GUI\\UI\\output_class_widget.ui")
            self.output_class_widget[output_class] = loader.load(os.path.join(os.path.dirname(st_dtdl_gui.__file__),"UI","output_class_widget.ui"), parent)
            class_name = self.output_class_widget[output_class].findChild(QLabel,"out_class_name")
            class_name.setText(output_class)
            if output_class != "ISPU": #NOTE Done for ISPU CES2023 Demo purposes
                self.output_class_widget[output_class].out_class_name.setStyleSheet("color: #383D48; font-size: 20px;")
            else:
                self.output_class_widget[output_class].out_class_name.setStyleSheet("color: #3cb4e6; font-size: 20px;")
            class_pixmap = QPixmap(self.out_classes[output_class])
            class_image:QLabel = self.output_class_widget[output_class].findChild(QLabel,"out_class_image")
            enabled_pixmap = class_pixmap
            disabled_pixmap = self.setOpacity(class_pixmap, 0.1)
            # self.setOpacity(disabled_pixmap, 0.1)
            self.output_class_pixmaps[output_class] = (enabled_pixmap, disabled_pixmap)
            if output_class != "ISPU": #NOTE Done for ISPU CES2023 Demo purposes
                class_image.setPixmap(disabled_pixmap)
            else:
                class_image.setPixmap(enabled_pixmap)
            frame_output_classes.layout().addWidget(self.output_class_widget[output_class])

        self.timer_interval_ms = self.timer_interval*700
        self.timer = QTimer() #to create a thread that calls a function at intervals
        self.timer.setTimerType(Qt.PreciseTimer)
        self.timer.timeout.connect(self.update_plot)#the update function keeps getting called at intervals
        
        #Main layout
        main_layout = QVBoxLayout()
        self.setLayout(main_layout)
        main_layout.addWidget(class_out_widget)
        
        frame_title.layout().addWidget(PlotLabel("{}".format(self.comp_display_name)))
        
    def setOpacity(self, pixmap:QPixmap, perc):
        new_pix = QPixmap(pixmap.size())
        new_pix.fill(Qt.transparent)
        painter = QPainter(new_pix)
        painter.setOpacity(perc)
        painter.drawPixmap(QPoint(), pixmap)
        painter.end()
        return new_pix
    
    def update_plot_characteristics(self, odr = 0, time_window = 0, n_curves = 0):
        pass
    
    @Slot()
    def clicked_pop_out_button(self):
        if self.is_docked:
            self.pop_out_widget()
            self.is_docked = False
        else:
            self.pop_in_widget()
            self.is_docked = True

    @Slot(bool)
    def s_is_logging(self, status: bool, interface: int):
        if interface == 1:
            print("Sensor {} is logging via USB: {}".format(self.comp_name,status))
            if status:
                self.buffering_timer_counter = 0
                self.timer.start(self.timer_interval_ms)
            else:
                self.timer.stop()
        else: # interface == 0
            print("Sensor {} is logging on SD Card: {}".format(self.comp_name,status))

    def reset(self):
        pass
    
    def update_plot(self):
        if self.buffering_timer_counter == 0:
            
            if len(self._data[0]) > 0: 
                
                # Extract all data from the queue (pop)    
                one_reduced_t_interval = [self._data[0].popleft() for _i in range(len(self._data[0]))]
                ort = one_reduced_t_interval[0][0]
                if ort == 0:
                    self.output_class_widget["Anomaly"].out_class_image.setPixmap(self.output_class_pixmaps["Anomaly"][1])
                    self.output_class_widget["Anomaly"].setEnabled(False)
                    self.output_class_widget["Anomaly"].findChild(QLabel,"out_class_name").setStyleSheet("color: #383D48; font-size: 20px;")
                    self.output_class_widget["Normal"].out_class_image.setPixmap(self.output_class_pixmaps["Normal"][0])
                    self.output_class_widget["Normal"].setEnabled(True)
                    self.output_class_widget["Normal"].findChild(QLabel,"out_class_name").setStyleSheet("color: #a4c238; font-size: 30px;")
                elif ort == 1:
                    self.output_class_widget["Anomaly"].out_class_image.setPixmap(self.output_class_pixmaps["Anomaly"][0])
                    self.output_class_widget["Anomaly"].setEnabled(True)
                    self.output_class_widget["Anomaly"].findChild(QLabel,"out_class_name").setStyleSheet("color: #e6007e; font-size: 30px;")
                    self.output_class_widget["Normal"].out_class_image.setPixmap(self.output_class_pixmaps["Normal"][1])
                    self.output_class_widget["Normal"].setEnabled(False)
                    self.output_class_widget["Normal"].findChild(QLabel,"out_class_name").setStyleSheet("color: #383D48; font-size: 20px;")
                # elif ort == 2:
                #     self.output_class_widget["Anomaly"].out_class_image.setPixmap(self.output_class_pixmaps["Anomaly"][1])
                #     self.output_class_widget["Anomaly"].setEnabled(False)
                #     self.output_class_widget["Anomaly"].findChild(QLabel,"out_class_name").setStyleSheet("color: #383D48; font-size: 20px;")
                #     self.output_class_widget["Normal"].out_class_image.setPixmap(self.output_class_pixmaps["Normal"][0])
                #     self.output_class_widget["Normal"].setEnabled(True)
                #     self.output_class_widget["Normal"].findChild(QLabel,"out_class_name").setStyleSheet("color: #a4c238; font-size: 30px;")
                # elif ort == 3:
                #     self.output_class_widget["Anomaly"].out_class_image.setPixmap(self.output_class_pixmaps["Anomaly"][1])
                #     self.output_class_widget["Anomaly"].setEnabled(False)
                #     self.output_class_widget["Anomaly"].findChild(QLabel,"out_class_name").setStyleSheet("color: #383D48; font-size: 20px;")
                #     self.output_class_widget["Normal"].out_class_image.setPixmap(self.output_class_pixmaps["Normal"][0])
                #     self.output_class_widget["Normal"].setEnabled(True)
                #     self.output_class_widget["Normal"].findChild(QLabel,"out_class_name").setStyleSheet("color: #a4c238; font-size: 30px;")

            self.app_qt.processEvents()
        else:
            # Increment the buffering counter (skip a plot timer interval to bufferize data from sensors)
            self.buffering_timer_counter += 1

    def add_data(self, data):
        self._data[0].append(data[0])
        
    def closeEvent(self, event):
        self.pop_in_widget()
        self.is_docked = True

    def pop_out_widget(self):
        self.setWindowFlags(Qt.Dialog | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        center = QScreen.availableGeometry(QApplication.primaryScreen()).center()
        geo = self.frameGeometry()
        geo.moveCenter(center)
        self.move(geo.topLeft())
        self.show()

    def pop_in_widget(self):
        self.setWindowFlags(Qt.Widget)
        self.parent.layout().insertWidget(self.p_id, self)
