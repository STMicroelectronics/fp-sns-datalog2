
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

import os
import struct
import numpy as np
from collections import deque

from PySide6.QtCore import Qt, Slot, QSize, QTimer
from PySide6.QtGui import QPainter, QFont, QScreen, QPixmap
from PySide6.QtWidgets import QWidget, QFrame, QVBoxLayout, QPushButton, QFileDialog
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QApplication
from PySide6.QtDesigner import QPyDesignerCustomWidgetCollection

import pyqtgraph as pg

import st_dtdl_gui
import st_dtdl_gui.UI.icons

from pkg_resources import resource_filename
ispu_out_fmt_ok_status_path = resource_filename('st_dtdl_gui.UI.icons', 'outline_done_outline_white_18dp.png')
ispu_out_fmt_ko_status_path = resource_filename('st_dtdl_gui.UI.icons', 'outline_close_white_36dp.png')

class PlotLabel(QWidget):
    def __init__(self, p_label, parent =None):
        super().__init__(parent)
        self.p_label = p_label
    
    def paintEvent(self, event):
        painter = QPainter(self)
        
        painter.setPen(Qt.white)
        painter.translate(painter.viewport().width() - 4, painter.viewport().height() - 4)
        painter.rotate(-90)
        bold = QFont()
        bold.setBold(True)
        painter.setFont(bold)
        painter.drawText(0, 0, self.p_label)
        painter.end()
        
class CustomPGPlotWidget(pg.PlotWidget):
    def __init__(self, parent=None, background='default', plotItem=None, **kargs):
        super().__init__(parent, background, plotItem, **kargs)
        self.parent = parent
        
    def wheelEvent(self, ev):
        if self.parent.is_docked:
            modifiers = QApplication.keyboardModifiers()
            if modifiers == Qt.ControlModifier:
                return super().wheelEvent(ev)
            else:
                return self.parent.wheelEvent(ev)
        else:
            return super().wheelEvent(ev)

class PlotWidget(QWidget):    
    def __init__(self, controller, comp_name, comp_display_name, odr, unit, time_window, n_curves=1, p_id = 0, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.controller = controller
        self.controller.sig_logging.connect(self.s_is_logging)
        self.controller.sig_plot_window_time_updated.connect(self.s_time_window_updated)
        self.controller.sig_tag_done.connect(self.s_tag_done)
        self.controller.sig_hsdv2_ispu_ucf_loaded.connect(self.s_ispu_ucf_loaded) #move in a HSD_GUI dediceted plot widget
        
        self.is_docked = True
        self.app_qt = self.controller.qt_app

        self.p_id = p_id
        self.comp_name = comp_name
        self.comp_display_name = comp_display_name
        self.unit = unit
        self.out_fmt_valid = None
        
        self.timer_interval = 0.2
        self.plot_len = 3000
        
        self.plot_t_interval_size = int(self.plot_len/(time_window / self.timer_interval))     
        self.one_t_interval_resampled = dict()
        
        QPyDesignerCustomWidgetCollection.registerCustomWidget(PlotWidget, module="PlotWidget")
        loader = QUiLoader()
        # plot_widget = loader.load("ST_DTDL_GUI\\UI\\plot_widget.ui", parent)
        plot_widget = loader.load(os.path.join(os.path.dirname(st_dtdl_gui.__file__),"UI","plot_widget.ui"), parent)
        title_frame = plot_widget.frame_plot.findChild(QFrame,"frame_title")
        contents_frame = plot_widget.frame_plot.findChild(QFrame,"frame_contents")
        pushButton_pop_out = title_frame.findChild(QPushButton, "pushButton_pop_out")
        pushButton_pop_out.clicked.connect(self.clicked_pop_out_button)
        load_output_fmt_frame = plot_widget.frame_plot.findChild(QFrame, "frame_load_out_fmt")
        if "_ispu" in comp_name:
            load_output_fmt_frame.setVisible(True)
            self.out_fmt_valid = False
            load_output_fmt_pushButton = load_output_fmt_frame.findChild(QPushButton, "pushButton_load_out_fmt")
            load_output_fmt_pushButton.clicked.connect(self.clicked_load_out_fmt_button)
            self.out_fmt_status = load_output_fmt_frame.findChild(QPushButton, "out_fmt_status")
            icon  = QPixmap(ispu_out_fmt_ko_status_path)
            self.out_fmt_status.setIcon(icon)
            load_output_fmt_frame.layout().addWidget(PlotLabel("OUT Format"))
        else:
            load_output_fmt_frame.setVisible(False)
        
        #Main layout
        main_layout = QVBoxLayout()
        self.setLayout(main_layout)
        main_layout.addWidget(plot_widget)
        
        title_frame.layout().addWidget(PlotLabel("{}".format(self.comp_display_name)))
        self.graph_widget = CustomPGPlotWidget(parent = self)
        
        self.graph_widget.getPlotItem().layout.setContentsMargins(10, 3, 3, 3)
        self.graph_widget.setMinimumSize(QSize(300, 150))
        
        styles = {'color':'#d2d2d2', 'font-size':'12px'}
        self.graph_widget.setLabel('left', self.unit, **styles)
        self.graph_widget.getAxis("left").setWidth(60)
        
        self.lines_colors = ['#e6007e', '#a4c238', '#3cb4e6', '#ef4f4f', '#46b28e', '#e8ce0e', '#60b562', '#f99e20', '#41b3ba']
        # Different color palettes
        # self.lines_colors = ["#e60049", "#0bb4ff", "#50e991", "#e6d800", "#9b19f5", "#ffa300", "#dc0ab4", "#b3d4ff", "#00bfa0"]
        # self.lines_colors = ['#e6007e', '#ef4f4f', '#f99e20', '#e8ce0e', '#a4c238', '#60b562', '#46b28e', '#41b3ba', '#3cb4e6']
        
        self.graph_widget.setBackground('#1b1d23')
        # self.graph_widget.setAntialiasing(True)
        self.graph_widget.showGrid(x=True, y=True)
        self.graph_curves = dict()
        self.active_tags = dict()
        self.tag_lines = []
        
        self._data = dict() # dict of queues
        self.y_queue = dict() # dict of queues
        
        self.update_plot_characteristics(odr, time_window, n_curves)
        
        #crosshair label in legend
        legend = self.graph_widget.addLegend()
        style = pg.PlotDataItem(pen='w')
        legend.anchor((0,0), (0,0))
        legend.addItem(style, 'coords')
        
        #cross hair in signalgraph
        crosshair_pen=pg.mkPen(color='#484A4F', style=Qt.DashLine)
        vLine = pg.InfiniteLine(angle=90, movable=False, pen=crosshair_pen)
        hLine = pg.InfiniteLine(angle=0, movable=False, pen=crosshair_pen)
        self.graph_widget.addItem(vLine, ignoreBounds=True)
        self.graph_widget.addItem(hLine, ignoreBounds=True)
        
        # VB
        vb = self.graph_widget.plotItem.vb

        def mouseMoved(evt):
            pos = evt
            if self.graph_widget.sceneBoundingRect().contains(pos):
                mousePoint = vb.mapSceneToView(pos)
                legend.getLabel(style).setText("""<span style='font-size: 9pt; 
                                                        color: #20b2aa;
                                                        font-weight: bold'>
                                                        x=
                                                        <span style='color: white;
                                                        font-weight: normal'>
                                                        %0.1f,
                                                        <span style='color: #20b2aa;
                                                        font-weight: bold;'>
                                                        y=
                                                        <span style='color: white;
                                                        font-weight: normal;'>
                                                        %0.1f
                                                </span>""" % (mousePoint.x(), mousePoint.y()))
                vLine.setPos(mousePoint.x())
                hLine.setPos(mousePoint.y())
        
        proxy = pg.SignalProxy(self.graph_widget.scene().sigMouseMoved, rateLimit=60, slot=mouseMoved)
        self.graph_widget.scene().sigMouseMoved.connect(mouseMoved)
        
        contents_frame.layout().addWidget(self.graph_widget)

        self.timer_interval_ms = self.timer_interval*1000
        self.timer = QTimer() #to create a thread that calls a function at intervals
        self.timer.setTimerType(Qt.PreciseTimer)
        self.timer.timeout.connect(self.update_plot)#the update function keeps getting called at intervals

    def update_plot_characteristics(self, odr, time_window, n_curves):
        self.odr = odr
        self.n_curves = n_curves
        self.time_window = time_window

        for i in range(self.n_curves):
           self.one_t_interval_resampled[i] = np.zeros(self.plot_t_interval_size)
        
        self.x_data = np.linspace(-(self.time_window), 0, self.plot_len)
        for i in range(self.n_curves):
            self._data[i] = deque(maxlen=200000)
            self.y_queue[i] = deque(maxlen=self.plot_len)
            self.y_queue[i].extend(np.zeros(self.plot_len))
            if len(self.graph_curves) < self.n_curves:
                self.graph_curves[i] = self.graph_widget.plot()
                # self.graph_curves[i] = pg.PlotCurveItem(pen=({'color': self.lines_colors[i - (len(self.lines_colors)* int(i / len(self.lines_colors)))], 'width': 1}), skipFiniteCheck=True, ignoreBounds=True)
                self.graph_curves[i] = pg.PlotDataItem(pen=({'color': self.lines_colors[i - (len(self.lines_colors)* int(i / len(self.lines_colors)))], 'width': 1}), skipFiniteCheck=True, ignoreBounds=True)
                self.graph_widget.addItem(self.graph_curves[i])
            
        self.app_qt.processEvents()
        
        self.plot_t_interval_size = int(self.plot_len/(self.time_window / self.timer_interval))
    
    @Slot()
    def clicked_pop_out_button(self):
        if self.is_docked:
            self.pop_out_widget()
            self.is_docked = False
        else:
            self.pop_in_widget()
            self.is_docked = True
            
    def __load_ispu_out_fmt(self, filepath):
        self.out_fmt_valid = self.controller.load_ispu_output_fmt_file(filepath)
        if self.out_fmt_valid:
            icon  = QPixmap(ispu_out_fmt_ok_status_path)
            self.ispu_output_format = self.controller.ispu_output_format["output"]
            self.ispu_out_bytes_cnt = []
            self.ispu_out_fmt_char = []
            for of in self.ispu_output_format:
                self.ispu_out_bytes_cnt.append(self.controller.get_out_fmt_byte_count(of["type"]))
                self.ispu_out_fmt_char.append(self.controller.get_out_fmt_char(of["type"]))
            self.n_curves = len(self.ispu_output_format)
            # self.update_plot_characteristics(self.odr, self.time_window, self.n_curves)
        else:
            icon  = QPixmap(ispu_out_fmt_ko_status_path)
        self.out_fmt_status.setIcon(icon)

    @Slot()
    def clicked_load_out_fmt_button(self):
        json_filter = "JSON Output format description Files (*.json *.JSON)"
        filepath = QFileDialog.getOpenFileName(filter=json_filter)
        self.__load_ispu_out_fmt(filepath[0])
            
    @Slot(float)
    def s_time_window_updated(self, new_time_w):
        self.update_plot_characteristics(self.odr, new_time_w, self.n_curves)
        
    @Slot()
    def s_tag_done(self, status, tag_label:str):
        if status:
            if not tag_label in self.active_tags or self.active_tags[tag_label] == False:
                self.active_tags[tag_label] = True
                pen=pg.mkPen(color='#00FF00', width=1)
                tag_line = pg.InfiniteLine(pos = self.x_data[-1], angle=90, movable=False, pen=pen, label=tag_label + " ON")
                self.graph_widget.addItem(tag_line, ignoreBounds=True)
                self.tag_lines.append(tag_line)
        else:
            if not tag_label in self.active_tags or self.active_tags[tag_label] == True:
                self.active_tags[tag_label] = False
                pen=pg.mkPen(color='#FF0000', width=1)
                tag_line = pg.InfiniteLine(pos = self.x_data[-1], angle=90, movable=False, pen=pen, label=tag_label + " OFF")
                self.graph_widget.addItem(tag_line, ignoreBounds=True)
                self.tag_lines.append(tag_line)
                
    @Slot(str)
    def s_ispu_ucf_loaded(self, output_json_fpath):
        if "_ispu" in self.comp_name:
            self.__load_ispu_out_fmt(output_json_fpath)

    @Slot(bool)
    def s_is_logging(self, status: bool, interface: int):
        if interface == 1:
            print("Sensor {} is logging via USB: {}".format(self.comp_name,status))
            if status:
                for t in self.tag_lines:
                    self.graph_widget.removeItem(t)
                self.tag_lines = []

                if "_ispu" in self.comp_name and self.out_fmt_valid:
                    self.n_curves = len(self.ispu_output_format)
                
                self.update_plot_characteristics(self.odr, self.time_window, self.n_curves)
                self.timer.start(self.timer_interval_ms)
            else:
                self.timer.stop()
        else: # interface == 0
            print("Sensor {} is logging on SD Card: {}".format(self.comp_name,status))

    def reset(self):
        pass
    
    def resample_linear1D(self, original, targetLen):
        original = np.array(original, dtype=float)
        index_arr = np.linspace(0, len(original)-1, num=targetLen, dtype=float)
        index_floor = np.array(index_arr, dtype=int) #Round down
        index_ceil = index_floor + 1
        index_rem = index_arr - index_floor #Remain
        
        val1 = original[index_floor]
        val2 = original[index_ceil % len(original)]
        interp = val1 * (1.0-index_rem) + val2 * index_rem
        assert(len(interp) == targetLen)
        return interp
    
    def update_plot(self):
        self.x_data = self.x_data + self.timer_interval
        for i in range(self.n_curves):
            if len(self._data[i]) > 0: # If data queue is not empty
                # Extract all data from the queue (pop)
                one_reduced_t_interval = [self._data[i].popleft() for _i in range(len(self._data[i]))]
                # Resample extracted raw data to have the same plot_timer_interval size (plot len / (time window / times interval(sec)))
                self.one_t_interval_resampled[i] = self.resample_linear1D(one_reduced_t_interval, self.plot_t_interval_size)
                # Put resampled data into the y data queue
                self.y_queue[i].extend(self.one_t_interval_resampled[i])
            else: #data queue is empty
                self.y_queue[i].extend(self.one_t_interval_resampled[i])
            # set extracted resampled data into the plot curve (for each axis) [x and y will have the same len = (plot len / (time window / times interval(sec)))
            self.graph_curves[i].setData(x=self.x_data,y=np.array(self.y_queue[i]))
        self.app_qt.processEvents()

    def add_data(self, data):
        if "_ispu" in self.comp_name:
            if self.out_fmt_valid == True:
                out_data = {}
                cnt = 0
                for i, out_len in enumerate(self.ispu_out_bytes_cnt):
                    out_data[i] = list(data.values())[cnt:out_len+cnt]
                    cnt += out_len
                    tmp = np.array(np.vstack(out_data[i]).flatten(),dtype='b')
                    out_data[i] = struct.unpack(self.ispu_out_fmt_char[i], tmp.tobytes())
                for i in range(self.n_curves):
                    self._data[i].extend(out_data[i])
        else:
            for i in range(self.n_curves):
                self._data[i].extend(data[i])

    def closeEvent(self, event):
        self.pop_in_widget()
        self.is_docked = True

    def pop_out_widget(self):
        self.setWindowFlags(Qt.Dialog | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        center = QScreen.availableGeometry(QApplication.primaryScreen()).center()
        geo = self.frameGeometry()
        geo.moveCenter(center)
        self.move(geo.topLeft())
        self.show()

    def pop_in_widget(self):
        self.setWindowFlags(Qt.Widget)
        self.parent.layout().insertWidget(self.p_id, self)

class PlotWidget_test_v1(PlotWidget):
    def __init__(self, controller, comp_name, s_id, ss_id, odr, time_window, spts, sample_size, data_format, n_curves=1, parent=None, p_id = 0):
        super().__init__(controller, comp_name, odr, time_window, n_curves, parent, p_id)
        self.s_id = s_id
        self.ss_id = ss_id
        self.sample_size = sample_size
        self.spts = spts
        self.data_format = data_format