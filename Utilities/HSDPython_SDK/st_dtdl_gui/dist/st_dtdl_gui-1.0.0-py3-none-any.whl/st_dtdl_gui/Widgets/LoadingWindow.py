from PySide6.QtWidgets import QProgressDialog

class LoadingWindow:
    
    def __init__(self, title, text, parent, app = None) -> None:
        # self.app = app
        self.dialog = QProgressDialog(parent)
        self.dialog.setMinimum(0)
        self.dialog.setMaximum(0)
        self.dialog.setLabelText(text)
        self.dialog.setWindowTitle(title)
        self.dialog.setCancelButton(None)
        self.dialog.setModal(True)
                
        style = '''
             QProgressDialog
             {
                 background-color: rgb(41, 45, 56);
             }
         '''
         
        self.dialog.setStyleSheet(style)
        self.dialog.show()
    
    def loadingDone(self):
        self.dialog.close()