
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

from enum import Enum

class UnitMap():
    
    def __init__(self) -> None:
        self.unit_dict = {
            "gForce":"g",
            "gauss":"G",
            "decibel":"dB",
            "mdps":"mdps",
            "degreeCelsius":"°C",
        }

class TypeEnum(Enum):
    STRING = "string"
    INTEGER = "integer"
    DOUBLE = "double"
    BOOLEAN = "boolean"
    ENUM = "enum"
    OBJECT = "object"

class DataClass(object):
    def __init__(self, comp_name, data):
        self.comp_name = comp_name
        self.data = data

class RawDataClass(object):
    def __init__(self, p_id, ssd, sss, data):
        self.p_id = p_id
        self.sss = sss
        self.ssd = ssd
        self.data = data

class PlotParams(object):
    def __init__(self, comp_name, enabled, odr, dimension, unit = "") -> None:
        self.comp_name = comp_name
        self.enabled = enabled
        self.odr = odr
        self.dimension = dimension
        self.unit = unit

class AlgPlotParams(PlotParams):
    def __init__(self, comp_name, enabled, alg_type, odr=1, dimension=1, unit="") -> None:
        super().__init__(comp_name, enabled, odr, dimension, unit)
        self.alg_type = alg_type

class FFTAlgPlotParams(AlgPlotParams):
    def __init__(self, comp_name, enabled, alg_type, fft_len, fft_sample_freq, unit="") -> None:
        super().__init__(comp_name, enabled, alg_type, 1, 1, unit)
        self.fft_len = fft_len
        self.fft_sample_freq = fft_sample_freq

class ClassificationModelPlotParams(AlgPlotParams):
    def __init__(self, comp_name, enabled, alg_type, num_of_class = 1, unit="") -> None:
        super().__init__(comp_name, enabled, alg_type, 1, 1, unit)
        self.num_of_class = num_of_class
        