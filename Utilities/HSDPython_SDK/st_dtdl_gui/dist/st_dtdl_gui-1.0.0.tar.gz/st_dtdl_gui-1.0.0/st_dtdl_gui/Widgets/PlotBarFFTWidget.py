 
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

import numpy as np

from st_dtdl_gui.Widgets.PlotBarWidget import PlotBarWidget

class PlotBarFFTWidget(PlotBarWidget):    
    def __init__(self, controller, comp_name, fft_len, fft_input_freq_hz, comp_display_name ="", unit= "dB", fft_bottom_val = -150, fft_top_val = -60, p_id = 0, parent=None):
        # Set FFT Specific parameters
        self.fft_len = fft_len
        self.fft_input_freq_hz = fft_input_freq_hz
        self.fft_width = (self.fft_input_freq_hz/2)/self.fft_len
        self.fft_bottom_val = fft_bottom_val
        self.fft_fft_top_val = fft_top_val

        super().__init__(controller = controller, comp_name=comp_name, comp_display_name = comp_display_name, n_bars=fft_len, bar_width= self.fft_width, unit = unit, p_id= p_id , parent=parent)

        self.x = np.arange(0, self.fft_width*(self.fft_len-1) ,self.fft_width,  dtype=int)
        self.bargraph.setY(fft_bottom_val)
        self.graph_widget.setYRange(fft_bottom_val, fft_top_val)
    
    def update_plot(self):
        if self.buffering_timer_counter == 0:
            
            if len(self._data[0]) > 0: 
                
                # Extract all data from the queue (pop)    
                one_reduced_t_interval = [self._data[0].popleft() for _i in range(len(self._data[0]))]
                y_value = np.array(one_reduced_t_interval)

                y_array_mean = np.mean(y_value, axis = 0)

                #Power spectral density
                y_value = np.square(y_array_mean)
                y_value =  y_value / (self.fft_len * self.fft_input_freq_hz)
                if y_value.any():
                    y_value =  10 * np.log10(y_value)
                    y_test = y_value - self.fft_bottom_val
                    self.bargraph.setOpts(x = self.x, height = y_test, brush ='#a4c238', pen='#1B1D23')
                else:
                    self.bargraph.setOpts(brush=(0,0,0,0), pen=(0,0,0,0))

            self.app_qt.processEvents()
        else:
            # Increment the buffering counter (skip a plot timer interval to bufferize data from sensors)
            self.buffering_timer_counter += 1

    