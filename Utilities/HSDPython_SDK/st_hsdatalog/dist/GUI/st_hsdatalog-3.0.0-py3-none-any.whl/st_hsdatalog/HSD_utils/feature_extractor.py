import matplotlib.pyplot as plt
import scipy
import numpy as np
import pandas as pd

from st_hsdatalog.HSD_utils.exceptions import FeaturExtractorError

import st_hsdatalog.HSD_utils.logger as logger
log = logger.get_logger(__name__)

class FeatureExtractor:

    # mean_df = {}
    # median_df = {}
    # max_df = {}
    # min_df = {}
    # var_df = {}
    # mode_df = {}
    # std_df = {}
    # kurt_df = {}
    # skew_df = {}

    def __init__(self, component_name, df, features, window_length, normalized_data):
        self.mean_df = {}
        self.median_df = {}
        self.max_df = {}
        self.min_df = {}
        self.var_df = {}
        self.mode_df = {}
        self.std_df = {}
        self.kurt_df = {}
        self.skew_df = {}
        self.dom_freq_df = {}
        #removes 'Time' column from the component dataframe
        filtered_df = df.drop('Time', axis=1)
        dataset = filtered_df.to_numpy()
        axis = len(df.values[0]) - 1
        
        timestamps_per_file = np.shape(dataset)[0]

        if timestamps_per_file < window_length:
            log.error("Not enough timestamps per file [{}]. Chosen another window_length value [{}]. It should be lower or equal to {}".format(timestamps_per_file, window_length, timestamps_per_file))
            raise FeaturExtractorError(component_name)
        
        #rearrange number of signals to the maximum number extractable from the array
        n_signals = int(np.floor((np.shape(dataset)[0])/window_length))
        filtered_df = filtered_df.iloc[:n_signals*window_length,:]
        # cropped_dataset = dataset[:n_signals*window_length]
        # filtered_df = pd.DataFrame(cropped_dataset)

        for a in range(axis):
            column_name = filtered_df.columns[a]
            filtered_data = filtered_df[column_name].values.astype(np.int16)

            if normalized_data:
                mean = np.mean(filtered_data)
                var = np.var(filtered_data)
                # print("{} MEAN: {}".format(column_name, mean))
                # print("{} VAR: {}".format(column_name, var))
                norm_data = (filtered_data - mean)/var
                reshaped_data = np.reshape(norm_data, (-1, window_length))
            else:
                reshaped_data = np.reshape(filtered_data, (-1, window_length))
            
            reshaped_df = pd.DataFrame(reshaped_data)
            print(reshaped_df)
            
            if "mean" in features:
                print("Mean feat")
                local_mean_df = pd.DataFrame()
                local_mean_df["{}_MEAN".format(column_name)] = reshaped_df.mean(axis=1)
                self.mean_df["{}_MEAN".format(column_name)] = local_mean_df
                print(self.mean_df["{}_MEAN".format(column_name)])
            
            if "median" in features:
                print("Median feat")
                local_median_df = pd.DataFrame()
                local_median_df["{}_MEDIAN".format(column_name)] = reshaped_df.median(axis=1)
                self.median_df["{}_MEDIAN".format(column_name)] = local_median_df
                print(self.median_df["{}_MEDIAN".format(column_name)])
            
            if "max" in features:
                print("Max feat")
                local_max_df = pd.DataFrame()
                local_max_df["{}_MAX".format(column_name)] = reshaped_df.max(axis=1)
                self.max_df["{}_MAX".format(column_name)] = local_max_df
                print(self.max_df["{}_MAX".format(column_name)])

            if "min" in features:
                print("Min feat")
                local_min_df = pd.DataFrame()
                local_min_df["{}_MIN".format(column_name)] = reshaped_df.min(axis=1)
                self.min_df["{}_MIN".format(column_name)] = local_min_df
                print(self.min_df["{}_MIN".format(column_name)])

            if "var" in features:
                print("Var feat")
                local_var_df = pd.DataFrame()
                local_var_df["{}_VAR".format(column_name)] = reshaped_df.var(axis=1)
                self.var_df["{}_VAR".format(column_name)] = local_var_df
                print(self.var_df["{}_VAR".format(column_name)])

            if "mode" in features:
                print("Mode feat")
                local_mode_df = pd.DataFrame()
                local_mode_df["{}_MODE".format(column_name)] = reshaped_df.mode(axis=1).iloc[:,:1]
                self.mode_df["{}_MODE".format(column_name)] = local_mode_df
                print(self.mode_df["{}_MODE".format(column_name)])

            if "std" in features:
                print("Std feat")
                local_std_df = pd.DataFrame()
                local_std_df["{}_STD".format(column_name)] = reshaped_df.std(axis=1)
                self.std_df["{}_STD".format(column_name)] = local_std_df
                print(self.std_df["{}_STD".format(column_name)])

            if "kurt" in features:
                print("Kurtosis feat")
                local_kurt_df = pd.DataFrame()
                local_kurt_df["{}_KURT".format(column_name)] = reshaped_df.kurt(axis=1)
                self.kurt_df["{}_KURT".format(column_name)] = local_kurt_df
                print(self.kurt_df["{}_KURT".format(column_name)])
            
            if "skew" in features:
                print("Skew feat")
                local_skew_df = pd.DataFrame()
                local_skew_df["{}_SKEW".format(column_name)] = reshaped_df.skew(axis=1)
                self.skew_df["{}_SKEW".format(column_name)] = local_skew_df
                print(self.skew_df["{}_SKEW".format(column_name)])

            if "dom_freq" in features:
                print("Dominant Frequency feat")
                local_dom_freq_df = pd.DataFrame()
                dominant_frequencies = []
                sampling_rate = 26667

                # fft_values = np.fft.fft(norm_data)
                # frequencies = np.fft.fftfreq(len(norm_data))
                # plt.plot(frequencies, np.abs(fft_values))
                # plt.xlabel('Frequency [Hz]')
                # plt.ylabel('Amplitude')
                # plt.title("FFT")
                # plt.show()
                
                #FFT megapower!
                # self.WelchPSD(norm_data, sampling_rate, 4096, enable_plot=True)

                # # temp_filtered_df = pd.DataFrame(filtered_data)
                # f, t, Sxx = scipy.signal.spectrogram(filtered_data, sampling_rate, nperseg=1024)
                # plt.pcolormesh(t, f, Sxx, shading='gouraud')
                # plt.ylabel('Frequency [Hz]')
                # plt.xlabel('Time [sec]')
                # plt.show()
            
                dominant_frequencies = self.frequency_peak(reshaped_df.to_numpy(), sampling_rate, 1024/3)
                local_dom_freq_df["{}_DOM_FREQ".format(column_name)] = dominant_frequencies
                self.dom_freq_df["{}_DOM_FREQ".format(column_name)] = local_dom_freq_df
                local_dom_freq_df.to_csv("dominant_frequencies.csv")
                # print(self.dom_freq_df["{}_DOM_FREQ".format(column_name)])

    #Standard PSD: taken from utils_signal_processing/SpectralAnalysis.py

    def WelchPSD(self, x, fs, winLen, overlap = 1/3, sigName = 'Signal', enable_plot= False, axis = -1):
        """"
        calculates the Welch power spectral density over a pd.Series or np.array

        Parameters:
        (numpy.array) x: windowed timeseries with shape (samples, winlen), where winlen represents the length of each segment of signal
        (int) fs: length of psd windows
        (str) sigName: signal name, used for plot title
        (Boolean) enable_plot: choice whether to plot the PSD or not
        (int) axis: dimension along which the psd is performed

        Returns:
        (numpy.array) f: array containing the frequency axis
        (numpy.array) Pxx: PSD calculated for each input sample (row)
        """
        nperseg = winLen #lenght of the window (RECT PERIODOGRAM)
        noverlap = int(winLen*overlap)
        nfft = nperseg*3
        f, Pxx = scipy.signal.welch(x, fs = fs, window = 'hamming', nperseg = nperseg, noverlap = noverlap, nfft = nfft, axis = axis)

        if enable_plot:
            plt.figure()
            plt.plot(f, Pxx)
            plt.title("Welch of %s (NFFT= %d, overlap = %d)" %(sigName, nfft, noverlap))
            plt.xlabel("frequency (Hz)")
            plt.ylabel("Power spectral density")
            plt.show()
        return f, Pxx

    def frequency_peak(self, x, fs, n_fft, axis = -1):
        """
        calculates the peak frequency: frequency with the highest amplitude in the signal.
        It can provide information about the frequency component that contributes the most to the signal.

        Parameters:
        (numpy.array) x: windowed timeseries with shape (samples, winlen), where winlen represents the length of each segment of signal
        (int) psd_window_length: length of psd windows
        (int) axis: dimension along which the psd is performed

        Returns:
        (numpy.array) peak_frequencies: array containing the peak_frequency calculated for each input sample (row)
        """
        f, Pxx = self.WelchPSD(x, fs, n_fft, overlap = 1/3, enable_plot= False, axis = axis)
        peak_frequencies = [f[np.where(pxx_i == max(pxx_i))][0] for pxx_i in Pxx]
        return peak_frequencies