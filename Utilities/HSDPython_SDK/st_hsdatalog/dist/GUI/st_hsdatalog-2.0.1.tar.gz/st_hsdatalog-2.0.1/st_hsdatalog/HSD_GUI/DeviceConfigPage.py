# *****************************************************************************
#  * @file    DeviceConfigPage.py
#  * @author  SRA
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

from PySide6.QtWidgets import QFrame, QWidget, QLabel
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Slot, Qt
from st_hsdatalog.HSD_GUI.Widgets.AppClassificationControlWidget import AppClassificationControlWidget
from st_hsdatalog.HSD_GUI.Widgets.HSDLogControlWidget import HSDLogControlWidget
from st_hsdatalog.HSD_GUI.Widgets.LogControlWidget import LogControlWidget

from st_hsdatalog.HSD_GUI.Widgets.TagsInfoWidget import TagsInfoWidget
from st_dtdl_gui.Widgets.ComponentWidget import ComponentWidget
from st_dtdl_gui.Widgets.PlotWidget import PlotWidget
from st_dtdl_gui.Widgets.PlotBarFFTWidget import PlotBarFFTWidget
from st_dtdl_gui.Widgets.ClassifierOutputWidget import ClassifierOutputWidget
from st_dtdl_gui.Utils.DataClass import PlotParams
from st_dtdl_gui.Controller import Controller
from st_dtdl_gui.Controller import ComponentType

import st_dtdl_gui.UI.images #NOTE don't delete this! it is used from resource_filename (@row 35)

from pkg_resources import resource_filename
st_logo_img_path = resource_filename('st_dtdl_gui.UI.images', 'st_logo.png')

import st_hsdatalog.HSD_utils.logger as logger
log = logger.setup_applevel_logger(is_debug = False, file_name= "app_debug.log")

class DeviceConfigPage():
    def __init__(self, page_widget, controller):
        self.controller:Controller = controller
        
        self.controller.sig_sensor_component_found.connect(self.s_sensor_component_found)
        self.controller.sig_algorithm_component_found.connect(self.s_algorithm_component_found)
        self.controller.sig_component_found.connect(self.s_component_found)

        self.controller.sig_sensor_component_updated.connect(self.sig_sensor_component_updated)
        self.controller.sig_algorithm_component_updated.connect(self.sig_algorithm_component_updated)

        self.controller.sig_component_removed.connect(self.s_component_removed)
        
        self.controller.sig_logging.connect(self.s_is_logging)

        self.page_widget = page_widget

        # layout_device_config
        self.main_layout = page_widget.findChild(QFrame, "frame_device_config")
        self.widget_header = self.main_layout.findChild(QWidget, "widget_header")
        self.log_control_widget = None
        
        self.device_config_widget = self.main_layout.findChild(QWidget,"widget_device_config")
        self.logging_message = QLabel(self.controller.get_log_msg())
        self.logging_message.setContentsMargins(12,6,12,6)
        self.logging_message.hide()
        self.device_config_widget.layout().addWidget(self.logging_message)
        self.plots_widget = self.main_layout.findChild(QWidget,"widget_plots")
        
        self.output_classes = {}

        self.threads_stop_flags = []
        self.sensor_data_files = []

        self.graph_id = 0
        self.comp_id = 0

    def remove_comp_widget(self, name):
        self.controller.remove_component_config_widget(name)
        
    def __get_nof_components(self):
        if self.controller.is_com_ok():
            return len(self.controller.hsd_link.get_device_status(self.controller.device_id)["devices"][self.controller.device_id]["components"])
        return 0
    
    @Slot(str, dict)
    def s_component_found(self, comp_name, comp_interface):
        #create a ComponentWidget
        comp_id = list(self.controller.components_dtdl.keys()).index(comp_name)
        comp_display_name = comp_interface.display_name if isinstance(comp_interface.display_name, str) else comp_interface.display_name.en
        if comp_name == "log_controller":
            c_status = self.controller.get_component_status(comp_name)
            if "controller_type" in c_status["log_controller"]:
                controller_type = c_status["log_controller"]["controller_type"]
                if controller_type == 0: #0 == HSD log controller
                    self.log_control_widget = HSDLogControlWidget(self.controller, comp_contents=comp_interface.contents, parent=self.widget_header)
                    self.controller.set_rtc_time()
                elif controller_type == 1: #1 == App classification controller
                    self.log_control_widget = AppClassificationControlWidget(self.controller, comp_contents=comp_interface.contents, parent=self.widget_header)
                elif controller_type == 2: #2 == Generic log controller
                    self.log_control_widget = LogControlWidget(self.controller, comp_contents=comp_interface.contents, parent=self.widget_header)
                    self.controller.set_rtc_time()
            else:
                #self.log_control_widget = AppClassificationControlWidget(self.controller, comp_contents=comp_interface.contents, parent=self.widget_header)
                self.log_control_widget = LogControlWidget(self.controller, comp_contents=comp_interface.contents, parent=self.widget_header)
                self.controller.set_rtc_time()
            self.controller.add_component_config_widget(self.log_control_widget)
            self.set_header_widget(self.log_control_widget)
            self.controller.fill_component_status(comp_name)
        elif comp_name == "tags_info":
            self.tags_info_widget = TagsInfoWidget(self.controller, comp_contents=comp_interface.contents, c_id=comp_id, parent=self.device_config_widget)
            self.controller.add_component_config_widget(self.tags_info_widget)
            self.device_config_widget.layout().addWidget(self.tags_info_widget)
            self.controller.fill_component_status(comp_name)
        elif comp_name == "applications_stblesensor":
            pass
        elif comp_name == "automode":
            pass
        else:
            comp_config_widget = ComponentWidget(self.controller, comp_name, comp_display_name, "", comp_interface.contents, comp_id, self.device_config_widget)
            self.controller.add_component_config_widget(comp_config_widget)
            self.device_config_widget.layout().addWidget(comp_config_widget)
            self.controller.fill_component_status(comp_name)
            
        if comp_id == self.__get_nof_components() - 1:
            st_logo_image = QLabel()
            st_logo_pixmap = QPixmap(st_logo_img_path)
            st_logo_image.setPixmap(st_logo_pixmap)
            st_logo_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
            st_logo_image.setContentsMargins(0,12,0,0)
            self.device_config_widget.layout().addWidget(st_logo_image)
    
    @Slot(str, dict)
    def s_sensor_component_found(self, comp_name, comp_interface):
        #create a ComponentWidget
        comp_display_name = comp_interface.display_name if isinstance(comp_interface.display_name, str) else comp_interface.display_name.en
        sensor_config_widget = ComponentWidget(self.controller, comp_name, comp_display_name, ComponentType.SENSOR, comp_interface.contents, self.comp_id, self.device_config_widget)
        self.comp_id += 1
        self.controller.add_component_config_widget(sensor_config_widget)
        self.device_config_widget.layout().addWidget(sensor_config_widget)
        
        enabled = self.controller.is_sensor_enabled(comp_name)
        sensor_plot_params:PlotParams = self.controller.get_plot_params(comp_name, comp_interface, ComponentType.SENSOR)
        if sensor_plot_params is not None:
            sensor_plot_widget = PlotWidget(self.controller, comp_name, comp_display_name, sensor_plot_params.odr, sensor_plot_params.unit, 30, sensor_plot_params.dimension, self.graph_id, self.plots_widget) 
            self.graph_id +=1
            self.controller.add_plot_widget(sensor_plot_widget)
            self.plots_widget.layout().addWidget(sensor_plot_widget)
            log.debug("comp_name: {} - status: {}".format(comp_name,enabled))
            sensor_plot_widget.setVisible(enabled)
        
        self.controller.fill_component_status(comp_name)

    @Slot(str, dict)
    def s_algorithm_component_found(self, comp_name, comp_interface):
        comp_display_name = comp_interface.display_name if isinstance(comp_interface.display_name, str) else comp_interface.display_name.en
        alg_config_widget = ComponentWidget(self.controller, comp_name, comp_display_name, ComponentType.ALGORITHM, comp_interface.contents, self.comp_id, self.device_config_widget)
        self.comp_id += 1
        self.controller.add_component_config_widget(alg_config_widget)
        self.device_config_widget.layout().addWidget(alg_config_widget)
        #enabled = self.controller.is_sensor_enabled(comp_name)
        #print(enabled)
 
        algorithm_plot_params = self.controller.get_plot_params(comp_name, comp_interface, ComponentType.ALGORITHM)
        if algorithm_plot_params is not None:
            alg_type = algorithm_plot_params.alg_type
            if alg_type == 0:
                alg_plot_widget = PlotBarFFTWidget(self.controller, comp_name, comp_display_name=comp_display_name, fft_len = algorithm_plot_params.fft_len, fft_input_freq_hz = algorithm_plot_params.fft_sample_freq, p_id=self.graph_id, parent=self.plots_widget)
                self.graph_id +=1
            elif alg_type == 1:
                out_classes = self.controller.get_output_classes()
                alg_plot_widget = ClassifierOutputWidget(self.controller, comp_name, comp_display_name, out_classes=out_classes, p_id=self.graph_id, parent=self.plots_widget)
                self.graph_id +=1

            
            self.controller.add_plot_widget(alg_plot_widget)
            self.plots_widget.layout().addWidget(alg_plot_widget)
            alg_plot_widget.setVisible(True)
        
        self.controller.fill_component_status(comp_name)        

    @Slot(str)
    def s_component_removed(self, comp_name):
        self.remove_comp_widget(comp_name)
    
    @Slot(str, PlotParams)
    def sig_sensor_component_updated(self, comp_name, plot_params:PlotParams):
        enabled = plot_params.enabled
        odr = plot_params.odr
        dimension = plot_params.dimension
        self.controller.update_plot_widget(comp_name, odr, 30, dimension, enabled)

    @Slot(str, PlotParams)
    def sig_algorithm_component_updated(self, comp_name, plot_params:PlotParams):
        enabled = plot_params.enabled
        odr = 0
        dimension = 1
        self.controller.update_plot_widget(comp_name, odr, 30, dimension, enabled)
    
    def __endisable_log_controller_components(self, status):
        if isinstance(self.log_control_widget, LogControlWidget):
            self.log_control_widget.interface_combobox.setEnabled(not status)
            self.log_control_widget.save_config_button.setEnabled(not status)
            self.log_control_widget.load_config_button.setEnabled(not status)
            self.log_control_widget.time_spinbox.setEnabled(not status)
        
    def __endisable_logging_message(self, status):
        if self.controller.get_log_msg() != "":
            self.logging_message.setText(self.controller.get_log_msg())
            self.logging_message.show() if status else self.logging_message.hide()
        
    def __endisable_component_config(self, status, c_to_avoid):
        for w in self.device_config_widget.findChildren(ComponentWidget):
            if w.comp_name not in c_to_avoid:
                w.contents_widget.setEnabled(not status)
                if status:
                    style_split = w.frame_component_config.styleSheet().split(';')
                    style_split[-1] = "\ncolor: rgb(100, 100, 100)"
                    w.frame_component_config.setStyleSheet(';'.join(style_split))
                else:
                    style_split = w.frame_component_config.styleSheet().split(';')
                    style_split[-1] = "\ncolor: rgb(210, 210, 210)"
                    w.frame_component_config.setStyleSheet(';'.join(style_split))
    
    def set_output_classes(self, output_classes):
        self.output_classess = output_classes
    
    def set_header_widget(self, widget):
        # clear all widgets in widget_header layout (contents)
        for i in reversed(range(self.widget_header.layout().count())):
            self.widget_header.layout().itemAt(i).widget().deleteLater()
        
        self.widget_header.layout().addWidget(self.log_control_widget)
    
    @Slot(bool)
    def s_is_logging(self, status:bool, interface:int):
        self.__endisable_log_controller_components(status)
        self.__endisable_logging_message(status)
        self.__endisable_component_config(status, ["tags_info","device_info"])
