
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

import os
from functools import partial

from PySide6.QtCore import Slot
from PySide6.QtWidgets import QFrame, QGridLayout
from PySide6.QtUiTools import QUiLoader
from PySide6.QtDesigner import QPyDesignerCustomWidgetCollection

from st_pnpl.DTDL.device_template_model import ContentSchema
from st_pnpl.PnPLCmd import PnPLCMDManager

from st_dtdl_gui.Widgets.ComponentWidget import ComponentWidget
from st_dtdl_gui.UI.styles import STDTDL_PushButton

import st_hsdatalog
import st_hsdatalog.HSD_utils.logger as logger
log = logger.setup_applevel_logger(is_debug = False, file_name= "app_debug.log")

class TagsInfoWidget(ComponentWidget):
    def __init__(self, controller, comp_contents, comp_name="tags_info", comp_display_name = "Tags Information" , comp_sem_type="other", c_id=0, parent=None):
        super().__init__(controller, comp_name, comp_display_name, comp_sem_type, comp_contents, c_id, parent)
        self.controller = controller
        self.comp_sem_type = comp_sem_type
        
        self.sw_tags_wgt_dict = dict()
        self.hw_tags_wgt_dict = dict()
        
        # clear all widgets in contents_widget layout (contents)
        for i in reversed(range(self.contents_widget.layout().count())):
            self.contents_widget.layout().itemAt(i).widget().deleteLater()

        self.setWindowTitle(comp_display_name)

        QPyDesignerCustomWidgetCollection.registerCustomWidget(TagsInfoWidget, module="TagsInfoWidget")
        loader = QUiLoader()
        tags_info_widget = loader.load(os.path.join(os.path.dirname(st_hsdatalog.__file__),"HSD_GUI","UI","tags_info_widget.ui"))
        frame_contents = tags_info_widget.frame_tags_info.findChild(QFrame,"frame_contents")
        # frame_sw_tags_title = tags_info_widget.frame_tags_info.findChild(QFrame,"frame_sw_tags_title")
        frame_sw_tags_contents = tags_info_widget.frame_tags_info.findChild(QFrame,"frame_sw_tags_contents")
        # frame_hw_tags_title = tags_info_widget.frame_tags_info.findChild(QFrame,"frame_hw_tags_title")
        frame_hw_tags_contents = tags_info_widget.frame_tags_info.findChild(QFrame,"frame_hw_tags_contents")

        sw_tags_grid_layout = QGridLayout()
        sw_tags_grid_layout.setContentsMargins(0,0,0,0)
        sw_tags_grid_layout.setHorizontalSpacing(0)
        sw_tags_grid_layout.setVerticalSpacing(0)
        
        hw_tags_grid_layout = QGridLayout()
        hw_tags_grid_layout.setContentsMargins(0,0,0,0)
        hw_tags_grid_layout.setHorizontalSpacing(0)
        hw_tags_grid_layout.setVerticalSpacing(0)
        
        w_on_col = 2
        r_id = 0
        c_id = 0
        
        hw_tags = [c for c in comp_contents if "hw_tag" in c.name]
        sw_tags = [c for c in comp_contents if "sw_tag" in c.name]
        
        for st in sw_tags:
            sw_tag_widget = loader.load(os.path.join(os.path.dirname(st_hsdatalog.__file__),"HSD_GUI","UI","sw_tag.ui"))
            sw_tag_widget.enable_tag_button.toggled.connect(partial(self.enable_tag_clicked, st.name))
            sw_tag_widget.tag_label.editingFinished.connect(partial(self.tag_label_changed, st.name))
            sw_tag_widget.tag_button.clicked.connect(partial(self.tag_button_clicked, st.name))
            sw_tag_widget.tag_button.setStyleSheet(STDTDL_PushButton.green)
            sw_tag_widget.tag_button.setEnabled(False)
            self.sw_tags_wgt_dict[st.name] = (sw_tag_widget, False) #Widget, tag_status (initially is False)
            sw_tags_grid_layout.addWidget(sw_tag_widget,r_id,c_id)
            c_id += 1
            if c_id == w_on_col:
                c_id = 0
                r_id += 1
                
        r_id += 1
        c_id = 0
                
        for ht in hw_tags:
            hw_tag_widget = loader.load(os.path.join(os.path.dirname(st_hsdatalog.__file__),"HSD_GUI","UI","hw_tag.ui"))
            hw_tag_widget.enable_tag_button.toggled.connect(partial(self.enable_tag_clicked, ht.name))
            hw_tag_widget.tag_label.editingFinished.connect(partial(self.tag_label_changed, ht.name))
            self.hw_tags_wgt_dict[ht.name] = hw_tag_widget
            hw_tags_grid_layout.addWidget(hw_tag_widget,r_id,c_id)
            c_id += 1
            if c_id == w_on_col:
                c_id = 0
                r_id += 1
        
        frame_sw_tags_contents.layout().addLayout(sw_tags_grid_layout)
        frame_hw_tags_contents.layout().addLayout(hw_tags_grid_layout)
        self.contents_widget.layout().addWidget(frame_contents)
    
    def enable_tag_clicked(self, tag_name, status):
        if "sw_tag" in tag_name:
            self.controller.changeSWTagClassEnabled(tag_name, status)
        elif "hw_tag" in tag_name:
            self.controller.changeHWTagClassEnabled(tag_name, status)
        
    def tag_button_clicked(self, tag_name):
        self.sw_tags_wgt_dict[tag_name] = (self.sw_tags_wgt_dict[tag_name][0], not self.sw_tags_wgt_dict[tag_name][1])
        tag_curr_status = self.sw_tags_wgt_dict[tag_name][1]
        if tag_curr_status is True:
            self.sw_tags_wgt_dict[tag_name][0].tag_button.setText("Tag OFF")
            self.sw_tags_wgt_dict[tag_name][0].tag_button.setStyleSheet(STDTDL_PushButton.red)
        else:
            self.sw_tags_wgt_dict[tag_name][0].tag_button.setText("Tag ON")
            self.sw_tags_wgt_dict[tag_name][0].tag_button.setStyleSheet(STDTDL_PushButton.green)
        self.controller.doTag(tag_name, tag_curr_status)
        
    def tag_label_changed(self, tag_name):
        if "sw_tag" in tag_name:
            tag_label = self.sw_tags_wgt_dict[tag_name][0].tag_label.text()
            self.controller.changeSWTagClassLabel(tag_name, tag_label)
        elif "hw_tag" in tag_name:
            tag_label = self.hw_tags_wgt_dict[tag_name].tag_label.text()
            self.controller.changeHWTagClassLabel(tag_name, tag_label)
    
    @Slot(bool)
    def s_is_logging(self, status:bool, interface:int):     
        if status:
            for st in self.sw_tags_wgt_dict:
                self.sw_tags_wgt_dict[st][0].tag_button.setEnabled(True)
                self.sw_tags_wgt_dict[st][0].enable_tag_button.setEnabled(False)
                self.sw_tags_wgt_dict[st][0].tag_label.setEnabled(False)
            for ht in self.hw_tags_wgt_dict:
                self.hw_tags_wgt_dict[ht].enable_tag_button.setEnabled(False)
                self.hw_tags_wgt_dict[ht].tag_label.setEnabled(False)
        else:
            for st in self.sw_tags_wgt_dict:
                self.sw_tags_wgt_dict[st][0].tag_button.setEnabled(False)
                self.sw_tags_wgt_dict[st][0].enable_tag_button.setEnabled(True)
                self.sw_tags_wgt_dict[st][0].tag_label.setEnabled(True)
            for ht in self.hw_tags_wgt_dict:
                self.hw_tags_wgt_dict[ht].enable_tag_button.setEnabled(True)
                self.hw_tags_wgt_dict[ht].tag_label.setEnabled(True)
            
    @Slot(int, str, dict)
    def s_component_updated(self, comp_name: str, comp_status: dict):
        if comp_name == "tags_info":
            # log.debug("Component: {}".format(comp_name))
            if comp_status is not None:
                # for cont_name, cont_value in comp_status.items():
                #     if type(cont_value) is dict:
                #         log.debug(" - Content: {}".format(cont_name))
                #         for key in cont_value:
                #             log.debug('  -- {} : {}'.format(key, cont_value[key]))
                for cs in comp_status:
                    if "sw_tag" in cs:
                        tag_widget = self.sw_tags_wgt_dict[cs][0]
                        tag_label = comp_status[cs]["label"]
                        tag_enabled = comp_status[cs]["enabled"]
                        tag_widget.tag_label.setText(tag_label)
                        tag_widget.enable_tag_button.setChecked(tag_enabled)
                    elif "hw_tag" in cs:
                        tag_widget = self.hw_tags_wgt_dict[cs]
                        tag_label = comp_status[cs]["label"]
                        tag_enabled = comp_status[cs]["enabled"]
                        tag_widget.tag_label.setText(tag_label)
                        tag_widget.enable_tag_button.setChecked(tag_enabled)
                self.controller.components_status[comp_name] = comp_status
                log.debug("Component: {}".format(comp_name))
                print("TagsInfoWidget - INFO - Component tags_info Updated correctly")
    
    @Slot()
    def plot_window_time_change(self):
        self.controller.plot_window_changed(self.time_spinbox.value())
    
