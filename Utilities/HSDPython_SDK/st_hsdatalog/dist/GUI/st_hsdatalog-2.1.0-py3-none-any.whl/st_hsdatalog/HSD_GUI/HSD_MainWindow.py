# *****************************************************************************
#  * @file    MainWindow.py
#  * @author  SRA
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

import st_dtdl_gui.UI.images #NOTE don't delete this! it is used from resource_filename (@row 35..38)
from st_dtdl_gui.STDTDL_MainWindow import STDTDL_MainWindow

from st_hsdatalog.HSD_GUI.HSD_DeviceConfigPage import HSD_DeviceConfigPage
from st_hsdatalog.HSD_GUI.HSD_Controller import HSD_Controller

from pkg_resources import resource_filename
motor_normal_img_path = resource_filename('st_dtdl_gui.UI.images', 'Motor_Normal_Class.png')
motor_anomaly_img_path = resource_filename('st_dtdl_gui.UI.images', 'Motor_Anomaly_Class.png')
motor_vibration_img_path = resource_filename('st_dtdl_gui.UI.images', 'Motor_Vibration_Class.png')
ispu_logo_img_path = resource_filename('st_dtdl_gui.UI.images', 'ISPU.png')
ai_output_img_path = resource_filename('st_dtdl_gui.UI.images', 'AI_Output.png')

import st_hsdatalog.HSD_utils.logger as logger
log = logger.setup_applevel_logger(is_debug = False, file_name= "app_debug.log")

class HSD_MainWindow(STDTDL_MainWindow):
    
    def __init__(self, app, parent=None):
        super().__init__(app, HSD_Controller(parent), parent)
        self.device_conf_page = HSD_DeviceConfigPage(self.configuration_widget, self.controller)
        
        self.supported_out_class_dict = {
            "Motor_Normal_class" : ("Normal" , motor_normal_img_path),
            "Motor_Anomaly_class" : ("Anomaly" , motor_anomaly_img_path),
            "Motor_Vibration_class" : ("Vibration" , motor_vibration_img_path),
            "ISPU" : ("ISPU", ispu_logo_img_path) #NOTE inserted here for ISPU CES 2023 demo purposes
        }
        self.out_classes = {}
        
        self.setWindowTitle("HSDatalog2")
        
    def setOutputClasses(self, class_names:list):
        for n in class_names:
            if n in self.supported_out_class_dict:
                out_c_name = self.supported_out_class_dict[n][0]
                out_c_img = self.supported_out_class_dict[n][1]
                self.out_classes[out_c_name] = out_c_img 
            else:
                self.out_classes[n] = ai_output_img_path
        self.controller.set_output_classes(self.out_classes)

    def getOutputClassDict(self):
        return self.out_classes

    def closeEvent(self, event):
        self.controller.stop_log()
        event.accept()