# *****************************************************************************
#  * @file    logger.py
#  * @author  SRA
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#

import logging
import sys
from datetime import datetime

LOGGER_NAME = "HSDatalogApp"

class CustomFormatter(logging.Formatter):

    grey = "\x1b[38;21m"
    yellow = "\x1b[33;21m"
    red = "\x1b[31;21m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"
    format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"

    FORMATS = {
        logging.DEBUG: grey + format + reset,
        logging.INFO: grey + format + reset,
        logging.WARNING: yellow + format + reset,
        logging.ERROR: red + format + reset,
        logging.CRITICAL: bold_red + format + reset
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)

def setup_applevel_logger( is_debug=True, 
                           file_name=None,
                           stream_handler=sys.stdout):
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.DEBUG if is_debug else logging.INFO)

    formatter = CustomFormatter()

    sh = logging.StreamHandler(stream_handler)
    sh.setFormatter(formatter)
    logger.handlers.clear()
    logger.addHandler(sh)

    if is_debug and file_name:
        fh = logging.FileHandler(file_name)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    return logger

def get_logger(module_name):
    return logging.getLogger(LOGGER_NAME).getChild(module_name)

def get_datetime():
    now = datetime.now()
    datetime_string = now.strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    return datetime_string