# *****************************************************************************
#  * @file    Controller.py
#  * @author  SRA
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
#
import time
import os
import json

from datetime import datetime
from threading import Thread, Event

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFileDialog

from st_pnpl.DTDL import device_template_model as DTM

from st_hsdatalog.HSD.HSDatalog import HSDatalog
from st_hsdatalog.HSD_link.HSDLink import HSDLink
from st_hsdatalog.HSD_link.HSDLink_v1 import HSDLink_v1

from st_hsdatalog.HSD_GUI.Widgets.HSDPlotLinesWidget import HSDPlotLinesWidget
from st_dtdl_gui.Utils.DataClass import AlgorithmPlotParams, SensorPlotParams, FFTAlgPlotParams, ClassificationModelPlotParams, DataClass, UnitMap
from st_dtdl_gui.Utils.DataReader import DataReader
from st_dtdl_gui.STDTDL_Controller import ComponentType, STDTDL_Controller

from st_hsdatalog.HSD.utils.type_conversion import TypeConversion

import st_hsdatalog.HSD_utils.logger as logger
log = logger.setup_applevel_logger(is_debug = False, file_name= "app_debug.log")

class HSD_Controller(STDTDL_Controller):
    
    # Signals
    sig_tag_done = Signal(bool, str) #(on|off),tag_label
    sig_hsdv2_ispu_ucf_loaded = Signal(str)
    
    class SensorAcquisitionThread(Thread):

        def __init__(self, event, hsd_link, data_reader, d_id, comp_name, sensor_data_file, usb_dps):            
            Thread.__init__(self)
            self.name = comp_name
            self.stopped = event
            self.hsd_link = hsd_link
            self.data_reader = data_reader
            self.d_id = d_id
            self.comp_name = comp_name
            self.sensor_data_file = sensor_data_file
            self.usb_dps = usb_dps
            self.over_proto = 0
            self.t0 = 0

        def run(self):
            while not self.stopped.wait(0.03):
                sensor_data = self.hsd_link.get_sensor_data(self.d_id, self.comp_name)
                if sensor_data is not None:
                    nof_usb_packet = len(sensor_data[1])/(self.usb_dps + 4)
                    #Data integrity Protocol. #NOTE [insert here the protocol check.]
                    for p in range(int(nof_usb_packet)):
                        self.data_reader.feed_data(DataClass(self.comp_name, sensor_data[1][p*(self.usb_dps + 4)+4: (p+1)*(self.usb_dps+4)]))
                    self.sensor_data_file.write(sensor_data[1])

    class SensorAcquisitionThread_test_v1(SensorAcquisitionThread):

        def __init__(self, event, hsd_link, data_reader, d_id, s_id, ss_id, comp_name, sensor_data_file):            
            self.s_id = s_id
            self.ss_id = ss_id
            super().__init__(self, event, hsd_link, data_reader, d_id, comp_name, sensor_data_file)

        def run(self):
            while not self.stopped.wait(0.2):
                sensor_data = self.hsd_link.get_sensor_data(self.d_id, self.s_id, self.ss_id)
                if sensor_data is not None:
                    self.data_reader.feed_data(DataClass(self.comp_name, sensor_data[1]))
                    self.sensor_data_file.write(sensor_data[1])

    def __init__(self, parent=None):
        super().__init__(parent)
        self.hsd_link = None
        self.is_hsd_link_up = False
        self.is_logging = False
        self.is_detecting = False
        self.refresh()
    
    def is_com_ok(self):
        return self.is_hsd_link_up
    
    #HSD
    def get_logging_status(self):
        return self.is_logging
    
    def get_device_formatted_name(self, device):
        if isinstance(device, dict) and "devices" in device:
            fw_info_tmp = [c for c in device["devices"][0]["components"] if "firmware_info" in list(c.keys())[0]]
            if len(fw_info_tmp) == 1:
                fw_info = fw_info_tmp[0]["firmware_info"]
                d_alias = fw_info["alias"]
                d_sn = fw_info["serial_number"]
                d_fw_name = fw_info["fw_name"]
                d_fw_version = fw_info["fw_version"]
                return "{} - [{}] {} v{}".format(d_alias, d_sn, d_fw_name, d_fw_version)
            else:
                if "board_id" in device["devices"][0]:
                    b_id = device["devices"][0]["board_id"]
                    if b_id == 14:
                        d_alias = "STWIN.box"
                    if b_id == 13:
                        d_alias = "SensorTile.box PRO"
                    return d_alias
        elif isinstance(self.hsd_link, HSDLink_v1):
            return "{} - [{}] {} v{}".format(device.device_info.alias, device.device_info.part_number, device.device_info.fw_name, device.device_info.fw_version)
    
    #HSD TODO duplicated API
    def set_rtc_time(self):
        now = datetime.now()
        time = now.strftime("%Y%m%d_%H_%M_%S")
        message = {"log_controller*set_time":{"datetime":time}}
        return self.send_command(json.dumps(message))
    
    def refresh(self):
        try:
            if self.hsd_link is not None:
                self.hsd_link.close()
                self.hsd_link = None
            hsd_link_factory = HSDLink()
            self.hsd_link = hsd_link_factory.create_hsd_link()
            if self.hsd_link is not None:
                self.is_hsd_link_up = True
        except Exception as err:
            log.error("Error: {}".format(err))
            if self.hsd_link is not None:
                self.hsd_link.close()
            self.is_hsd_link_up = False
            self.sig_com_init_error.emit()
        self.sensors_threads = []
        self.threads_stop_flags = []
        self.sensor_data_files = []
        self.data_readers = []
        self.ispu_output_format = None
        self.log_msg = ""
    
    def get_device_list(self):
        devices = self.hsd_link.get_devices() 
        return devices
    
    def get_device_presentation_string(self, d_id = 0):
        if type(self.hsd_link) == HSDLink_v1:
            return None
        return self.hsd_link.get_device_presentation_string(d_id)

    def get_device_info(self, d_id = 0):
        return self.hsd_link.get_device_info(d_id)
    
    def load_device_template(self, board_id, fw_id):
        self.sig_dtm_loading_started.emit()
        dev_template_json = self.query_dtdl_model(board_id, fw_id)
        if dev_template_json == "":
            log.error("Connected device not supported (Unrecognized board_id, fw_id)")
        
        super().load_local_device_template(dev_template_json)
        self.hsd_link.set_device_template(dev_template_json)
        self.sig_dtm_loading_completed.emit()
        
    def load_local_device_template(self, input_dt_file_path):
        with open(input_dt_file_path, 'r', encoding='utf-8') as json_file:
            dev_template_json = json.load(json_file)
            json_file.close()
        super().load_local_device_template(dev_template_json)
        self.hsd_link.set_device_template(dev_template_json)

    def is_sensor_enabled(self, comp_name, d_id = 0):
        return self.hsd_link.get_sensor_enable(d_id, comp_name)
    
    def get_component_status(self, comp_name):
        return self.hsd_link.get_component_status(self.device_id, comp_name)

    def get_plot_params(self, comp_name, comp_interface, comp_type):
        comp_status = self.hsd_link.get_component_status(self.device_id, comp_name)
        if comp_status is not None and comp_name in comp_status:
            if comp_type.name == ComponentType.SENSOR.name:
                comp_status_value = comp_status[comp_name]
                enabled = comp_status_value["enable"]
                if "odr" in comp_status_value:
                    odr_index = comp_status_value["odr"]
                    odr_enum_dname = [c for c in comp_interface.contents if c.name == "odr"][0].schema.enum_values[odr_index].display_name
                    odr_value = odr_enum_dname if isinstance(odr_enum_dname,str) else odr_enum_dname.en
                    odr_value = odr_value.replace(',','.')
                    odr = float(odr_value)
                else:
                    odr = 1    
                unit = ""
                if "fs" in comp_status_value:
                    fs_cont = [c for c in comp_interface.contents if c.name == "fs"][0]
                    if fs_cont.unit is not None:
                        unit = fs_cont.unit
                    elif fs_cont.display_unit is not None:
                        unit = fs_cont.display_unit if isinstance(fs_cont.display_unit, str) else fs_cont.display_unit.en
                elif "aop" in comp_status_value:
                    aop_cont = [c for c in comp_interface.contents if c.name == "aop"][0]
                    if aop_cont.unit is not None:
                        unit = aop_cont.unit
                    elif aop_cont.display_unit is not None:
                        unit = aop_cont.display_unit if isinstance(aop_cont.display_unit, str) else aop_cont.display_unit.en
                        
                unit_dict = UnitMap().unit_dict
                if unit in unit_dict:
                    unit = unit_dict[unit]
                
                dimension = comp_status_value["dim"]

                return SensorPlotParams(comp_name, enabled, odr, dimension, unit)
            
            elif comp_type.name == ComponentType.ALGORITHM.name:
                
                comp_status_value = comp_status[comp_name]
                enabled = comp_status_value["enable"]
                if "algorithm_type" in comp_status_value:
                    alg_type =  comp_status_value["algorithm_type"]
                else:
                    alg_type = 0
                
                if alg_type == 0:
                    return FFTAlgPlotParams(comp_name, 
                                            enabled,
                                            fft_len=comp_status_value["dim"], 
                                            fft_sample_freq= comp_status_value["fft_sample_freq"], 
                                            y_label = "db")
                elif alg_type == 1:
                        return ClassificationModelPlotParams( comp_name,
                                                              enabled,
                                                              num_of_class= comp_status_value["dim"])
        return None

    def fill_component_status(self, comp_name):
        comp_status = self.hsd_link.get_component_status(self.device_id, comp_name)
        if comp_status is not None and comp_name in comp_status:
            self.sig_component_updated.emit(comp_name, comp_status[comp_name])
        else:
            log.warning("The component [{}] defined in DeviceTemplate has not a Twin in Device Status from the FW".format(comp_name))
            self.sig_component_updated.emit(comp_name, None)
            has_cmd_or_tele_contents = False
            contents = self.components_dtdl[comp_name].contents 
            for c in contents:
                if isinstance(c.type, list):
                    has_cmd_or_tele_contents = len([cc for cc in c.type if cc == DTM.ContentType.COMMAND or cc == DTM.ContentType.TELEMETRY]) > 0
                else:
                    has_cmd_or_tele_contents = len([c for c in contents if c.type == DTM.ContentType.COMMAND or c.type == DTM.ContentType.TELEMETRY]) > 0
                if has_cmd_or_tele_contents == True:
                    return
            self.remove_component_config_widget(comp_name)

    def update_component_status(self, comp_name, comp_type = ComponentType.OTHER):
        comp_status = self.hsd_link.get_component_status(self.device_id, comp_name)
        if comp_status is not None and comp_name in comp_status:
            if isinstance(comp_type,str):
                ct = comp_type
            else:
                ct = comp_type.name
            if ct == ComponentType.SENSOR.name:
                plot_params = self.get_plot_params(comp_name, self.components_dtdl[comp_name], comp_type)
                self.sig_sensor_component_updated.emit(comp_name, plot_params)
            elif  ct == ComponentType.ALGORITHM.name:
                comp_status_value = comp_status[comp_name]
                self.components_status[comp_name] = comp_status_value
                plot_params = AlgorithmPlotParams(comp_name,comp_status_value["enable"], "")
                self.sig_algorithm_component_updated.emit(comp_name, plot_params)
            self.sig_component_updated.emit(comp_name, comp_status[comp_name])
        else:
            log.warning("The component [{}] defined in DeviceTemplate has not a Twin in Device Status from the FW".format(comp_name))
            self.sig_component_updated.emit(comp_name, None)
    
    def update_device_status(self):
        dev_status = self.hsd_link.get_device_status(self.device_id)
        for c in dev_status["devices"][self.device_id]["components"]:
            c_dict = list(c.values())[0]
            c_name = list(c.keys())[0]
            c_type = ComponentType.OTHER
            if "c_type" in c_dict:
                if c_dict["c_type"] == 0:
                    c_type = ComponentType.SENSOR
                elif c_dict["c_type"] == 1:
                    c_type = ComponentType.ALGORITHM
            self.update_component_status(c_name, c_type)

    def start_log(self, interface=1):
        if type(self.hsd_link) == HSDLink_v1:
            res = self.hsd_link.start_log(self.device_id)
        else:
            res = self.hsd_link.start_log(self.device_id, interface)
        if res:
            self.sig_logging.emit(True,interface)
            self.is_logging = True
            
    def start_detect(self):
        if type(self.hsd_link) == HSDLink_v1:
            res = self.hsd_link.start_log(self.device_id)
        else:
            res = self.hsd_link.start_log(self.device_id, 1)
        if res:
            self.sig_detecting.emit(True)
            self.is_detecting = True

    def start_plots(self):
         for s in self.plot_widgets:
            s_plot = self.plot_widgets[s]
            
            if type(self.hsd_link) == HSDLink_v1:
                    sensor_data_file_path = os.path.join(self.hsd_link.get_acquisition_folder(),(str(s_plot.comp_name) + ".dat"))
                    sensor_data_file = open(sensor_data_file_path, "wb+")
                    self.sensor_data_files.append(sensor_data_file)
                    stopFlag = Event()
                    self.threads_stop_flags.append(stopFlag)

                    dimensions = s_plot.n_curves
                    sample_size = s_plot.sample_size
                    spts = s_plot.spts
                    data_format = s_plot.data_format
                    
                    dr = DataReader(self, s_plot.comp_name, spts, dimensions, sample_size, data_format)
                    self.data_readers.append(dr)
                    
                    thread = self.SensorAcquisitionThread_test_v1(stopFlag, self.hsd_link, dr, self.device_id, s_plot.s_id, s_plot.ss_id, s_plot.comp_name, sensor_data_file)
                    thread.start()
                    self.sensors_threads.append(thread)
            else:
                c_status = self.hsd_link.get_component_status(self.device_id, s_plot.comp_name)
                c_status_value = c_status[s_plot.comp_name]
                
                c_enable = c_status_value["enable"] 
                
                if c_enable == True:
                    sensor_data_file_path = os.path.join(self.hsd_link.get_acquisition_folder(),(str(s_plot.comp_name) + ".dat"))
                    sensor_data_file = open(sensor_data_file_path, "wb+")
                    self.sensor_data_files.append(sensor_data_file)
                    stopFlag = Event()
                    self.threads_stop_flags.append(stopFlag)

                    if "sensitivity" in c_status_value:
                        sensitivity = c_status_value["sensitivity"]
                    else:
                        sensitivity = 1
                    
                    sample_size = self.sample_size_from_data_type(c_status_value["data_type"])
                    data_format = self.data_format_from_data_type(c_status_value["data_type"])
                    usb_dps = c_status_value["usb_dps"]

                    interleaved_data = True
                    if c_status_value["c_type"] == ComponentType.SENSOR.value:
                        spts = c_status_value["samples_per_ts"]["val"]
                        dimensions = c_status_value["dim"]
                        
                    elif c_status_value["c_type"] == ComponentType.ALGORITHM.value:
                        spts = 0
                        dimensions = c_status_value["dim"]
                        if "algorithm_type" in c_status_value:
                            algorithm_type = c_status_value["algorithm_type"]
                        if algorithm_type == 0 or algorithm_type == 1:
                            interleaved_data = False
                    
                    elif c_status_value["c_type"] == ComponentType.ACTUATOR.value:
                        spts = 1
                        dimensions = c_status_value["n_params"]


                    if "_ispu" in s_plot.comp_name:
                        data_format = "b"
                        dimensions = 64
                        sample_size = 1
                    dr = DataReader(self, s_plot.comp_name, spts, dimensions, sample_size, data_format, sensitivity, interleaved_data)
                    self.data_readers.append(dr)
                
                    thread = self.SensorAcquisitionThread(stopFlag, self.hsd_link, dr, self.device_id, s_plot.comp_name, sensor_data_file, usb_dps)
                    thread.start()
                    self.sensors_threads.append(thread)

    def stop_log(self, interface=1):
        if self.is_logging == True:
            self.hsd_link.stop_log(self.device_id)
            if type(self.hsd_link) == HSDLink_v1:
                self.hsd_link.save_json_device_file(self.device_id)
                self.hsd_link.save_json_acq_info_file(self.device_id)
            else:
                #TODO put here a "File saving..." loading window!
                self.hsd_link.save_json_acq_info_file(self.device_id)
                time.sleep(0.5)
                self.hsd_link.save_json_device_file(self.device_id)
                if self.ispu_output_format is not None:
                    self.save_json_ispu_output_format_file()
            self.sig_logging.emit(False, interface)
            self.is_logging = False
    
    def stop_detect(self):
        if self.is_detecting == True:
            self.hsd_link.stop_log(self.device_id)
            if type(self.hsd_link) == HSDLink_v1:
                self.hsd_link.save_json_device_file(self.device_id)
                self.hsd_link.save_json_acq_info_file(self.device_id)
            else:
                self.hsd_link.save_json_device_file(self.device_id)
                self.hsd_link.save_json_acq_info_file(self.device_id)
                if self.ispu_output_format is not None:
                    self.save_json_ispu_output_format_file()
            self.sig_detecting.emit(False)
            self.is_detecting = False
    
    def stop_plots(self):
        for sf in self.threads_stop_flags:
            sf.set()
        for f in self.sensor_data_files:
            f.close()

    def save_json_ispu_output_format_file(self):
        out_fmt_json_path = os.path.join(self.hsd_link.get_acquisition_folder(),"ispu_output_format.json")
        out_fmt_file = open(out_fmt_json_path, "w+")
        out_fmt_file.write(json.dumps(self.ispu_output_format, indent = 4))
        out_fmt_file.close()
    
    def plot_window_changed(self, plot_window_time):
        self.sig_plot_window_time_updated.emit(plot_window_time)
    
    def get_plot_widget(self, comp_name):
        if comp_name in self.plot_widgets:
            return self.plot_widgets[comp_name]
        else:
            return None
    
    def add_plot_widget(self, plot_widget):
        self.plot_widgets[plot_widget.comp_name] = (plot_widget)

    def update_plot_widget(self, comp_name, plot_params, visible):
        self.plot_widgets[comp_name].update_plot_characteristics(plot_params)
        self.plot_widgets[comp_name].setVisible(visible)

    def remove_plot_widget(self, comp_name) -> HSDPlotLinesWidget:
        if comp_name in self.plot_widgets:
            return self.plot_widgets.pop(comp_name)
        else:
            log.warning("{} is not in plot widget list yet".format(comp_name))

    def add_data_to_a_plot(self, data:DataClass):
        self.plot_widgets[data.comp_name].add_data(data.data)

    def connect_to(self, d_id:int, d_text:str = None):
        self.sig_device_connected.emit(True)
        self.device_id = d_id

    def disconnect(self):
        self.sig_device_connected.emit(False)
        for pw in self.plot_widgets:
            self.plot_widgets[pw].deleteLater()
        self.plot_widgets.clear()
        
        for cw in self.cconfig_widgets:
            self.cconfig_widgets[cw].deleteLater()
        self.cconfig_widgets.clear()
        
        self.components_dtdl.clear() #From DTDL DeviceModel 
        self.components_status.clear() #From FW

    def send_command(self, json_command):
        self.hsd_link.send_command(self.device_id, json_command)
        log.info("Command sent: {}".format(json_command))
    
    def get_device_status(self):
        return self.hsd_link.get_device_status(self.device_id)
    
    def save_config(self, on_pc:bool, on_sd:bool):
        if on_pc:
            fname = QFileDialog.getSaveFileName(None, "Save Current Device Configuration", "device_config", "JSON (*.json)")
            with open(fname[0], 'w', encoding='utf-8') as f:
                json.dump(self.get_device_status(), f, ensure_ascii=False, indent=4)
        if on_sd:
            self.hsd_link.save_config(self.device_id)
            
    def load_config(self, fpath):
        self.hsd_link.update_device(self.device_id, fpath)
        self.update_device_status()
        
    def load_ispu_output_fmt_file(self, fpath):
        try:
            with open(fpath) as f:
                file_content = f.read()
                if file_content[-1] == '\x00':
                    ispu_out_json_dict = json.loads(file_content[:-1])
                else:
                    ispu_out_json_dict = json.loads(file_content)
            ispu_out_json_str = json.dumps(ispu_out_json_dict)
            f.close()
            self.ispu_output_format = json.loads(ispu_out_json_str)
            return True
        except:
            return False
    
    def get_out_fmt_byte_count(self, of_type):
        return TypeConversion.check_type_length(of_type)
    
    def get_out_fmt_char(self, of_type):
        return TypeConversion.get_format_char(of_type)
    
    def upload_file(self, comp_name, fpath):
        #TODO
        log.error("Component: {} Generic file Upload feature not yet implemented".format(comp_name))
    
    def upload_mlc_ucf_file(self, comp_name, ucf_fpath):
        self.hsd_link.upload_mlc_ucf_file(self.device_id, comp_name, ucf_fpath)
        
    def upload_ispu_ucf_file(self, comp_name, ucf_fpath, output_json_fpath):
        self.hsd_link.upload_ispu_ucf_file(self.device_id, comp_name, ucf_fpath, output_json_fpath)
        self.sig_hsdv2_ispu_ucf_loaded.emit(output_json_fpath)
        
    def doTag(self, sw_tag_name, status):
        if status is True:
            self.hsd_link.set_sw_tag_on(self.device_id, sw_tag_name)
        else:
            self.hsd_link.set_sw_tag_off(self.device_id, sw_tag_name)
        self.update_component_status("tags_info")
        tag_label = self.components_status["tags_info"][sw_tag_name]["label"]
        self.sig_tag_done.emit(status, tag_label)

    def changeSWTagClassEnabled(self, sw_tag_name, new_status):
        self.hsd_link.set_sw_tag_class_enabled(self.device_id, sw_tag_name, new_status)
        
    def changeHWTagClassEnabled(self, hw_tag_name, new_status):
        self.hsd_link.set_hw_tag_class_enabled(self.device_id, hw_tag_name, new_status)
    
    def changeSWTagClassLabel(self, sw_tag_name, new_label):
        self.hsd_link.set_sw_tag_class_label(self.device_id, sw_tag_name, new_label)
        
    def changeHWTagClassLabel(self, hw_tag_name, new_label):
        self.hsd_link.set_hw_tag_class_label(self.device_id, hw_tag_name, new_label)
    
    def set_output_classes(self, output_classes):
        self.output_classes = output_classes
    
    def get_output_classes(self):
        return self.output_classes

    def set_rtc_time(self):
        self.hsd_link.set_rtc_time(self.device_id)
    
    def do_offline_plots(self, cb_sensor_value, tag_label, start_time, end_time, active_sensor_list, active_algorithm_list, debug_flag, sub_plots_flag, raw_data_flag):
        acquisition_folder = self.hsd_link.get_acquisition_folder()
        hsd_factory = HSDatalog()
        hsd = hsd_factory.create_hsd(acquisition_folder)
        
        hsd.enable_timestamp_recovery(debug_flag)
        if tag_label == "None" or  tag_label == '':
            tag_label = None
        if cb_sensor_value == "all":
            for s in active_sensor_list:
                s_key = list(s.keys())[0]
                hsd.get_sensor_plot(s_key, None, start_time, end_time, tag_label if tag_label != "None" else None, sub_plots_flag, raw_data_flag)
            for a in active_algorithm_list:
                a_key = list(a.keys())[0]
                hsd.get_algorithm_plot(a_key, start_time, end_time)
        else:
            s_list = hsd.get_sensor_list(only_active=True)
            a_list = hsd.get_algorithm_list(only_active=True)
            sensor_comp = [s for s in s_list if cb_sensor_value in s]
            algo_comp = [a for a in a_list if cb_sensor_value in a]
            if len(sensor_comp) > 0: # == 1
                hsd.get_sensor_plot(cb_sensor_value, None, start_time, end_time, tag_label if tag_label != "None" else None, sub_plots_flag, raw_data_flag)
            elif len(algo_comp) > 0: # == 1
                a_key = list(algo_comp[0].keys())[0]
                hsd.get_algorithm_plot(a_key, start_time, end_time)
        
        self.sig_offline_plots_completed.emit()
    
    def convert_dat2wav(self, comp_name, start_time, end_time):
        acquisition_folder = self.hsd_link.get_acquisition_folder()
        hsd_factory = HSDatalog()
        hsd = hsd_factory.create_hsd(acquisition_folder)
    
        output_folder = acquisition_folder + "_Exported"  
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        hsd.enable_timestamp_recovery(True)
        component = HSDatalog.get_component(hsd, comp_name)
        if component is not None:
            HSDatalog.convert_dat_to_wav(hsd, component, start_time, end_time, output_folder)
        
        wav_file_name = HSDatalog.get_wav_file_name(hsd, comp_name, None, output_folder)
        self.sig_wav_conversion_completed.emit(comp_name, wav_file_name)